# mlworkshop
Stephen Wylie's machine learning presentations

## Prerequisites
Depending on your course of study (Google APIs and/or Tensorflow), please see the README file in each of those directories in this repository in order to run the setup steps to activate your Google APIs and set up enough interesting data for you to run the examples.
